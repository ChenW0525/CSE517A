See 02NaiveBayes.html
